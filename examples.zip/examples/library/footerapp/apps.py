from django.apps import AppConfig


class FooterappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'footerapp'
